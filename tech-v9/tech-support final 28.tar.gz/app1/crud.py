def searchp(request):
    if not request.user.is_staff:
        return HttpResponseRedirect(reverse('rest'))
    form1 = search1((request.POST or None))
    form2 = search2(request.POST or None)
    form3 = search3(request.POST or None)

    if form1.is_valid() and form2.is_valid() and form3.is_valid():
        sectorname = form1.cleaned_data['select_sector']
        problem = form2.cleaned_data['select_problem']
        username = form3.cleaned_data['select_user']
        if sectorname == '' and problem == '' and username == '':
            title = "there is no search criteria entered"
            res = ""
            context = {"f1": form1, "f2": form2, "f3": form3, "title": title}

        elif sectorname and problem == 'HardWare' and username == '':
            res = hw_malfunction.objects.filter(user_sector__icontains=sectorname)
            cont1 = {"q": res, "f1": form1, "f2": form2, "f3": form3}
            return render(request, "searchc.html", cont1)

        elif sectorname and problem == 'Network' and username == '':
            res = nw_malfunction.objects.filter(user_sector__icontains=sectorname)
            cont1 = {"q": res, "f1": form1, "f2": form2, "f3": form3}
            return render(request, "searchc.html", cont1)

        elif sectorname and problem == 'Printers' and username == '':
            res = print_malfunction.objects.filter(user_sector__icontains=sectorname)
            cont1 = {"q": res, "f1": form1, "f2": form2, "f3": form3}
            return render(request, "searchc.html", cont1)

        elif sectorname and problem == '' and username == '':
            hw_qs = hw_malfunction.objects.filter(user_sector__icontains=sectorname)
            nw_qs = nw_malfunction.objects.filter(user_sector__icontains=sectorname)
            p_qs = print_malfunction.objects.filter(user_sector__icontains=sectorname)
            res = list(chain(hw_qs, nw_qs, p_qs))
            cont1 = {"q": res, "f1": form1, "f2": form2, "f3": form3}
            return render(request, "searchc.html", cont1)

        elif sectorname and username and problem == '':
            hw_qs = hw_malfunction.objects.filter(user_sector__icontains=sectorname, user_fullname__icontains=username)
            nw_qs = nw_malfunction.objects.filter(user_sector__icontains=sectorname, user_fullname__icontains=username)
            p_qs = print_malfunction.objects.filter(user_sector__icontains=sectorname,
                                                    user_fullname__icontains=username)
            res = list(chain(hw_qs, nw_qs, p_qs))
            cont1 = {"q": res, "f1": form1, "f2": form2, "f3": form3}
            return render(request, "searchc.html", cont1)
        elif sectorname and username and problem == 'HardWare':
            res = hw_malfunction.objects.filter(user_sector__icontains=sectorname, user_fullname__icontains=username)
            cont1 = {"q": res, "f1": form1, "f2": form2, "f3": form3}
            return render(request, "searchc.html", cont1)
        elif sectorname and username and problem == 'Network':
            res = nw_malfunction.objects.filter(user_sector__icontains=sectorname, user_fullname__icontains=username)
            cont1 = {"q": res, "f1": form1, "f2": form2, "f3": form3}
            return render(request, "searchc.html", cont1)
        elif sectorname and username and problem == 'Printers':
            res = print_malfunction.objects.filter(user_sector__icontains=sectorname, user_fullname__icontains=username)
            cont1 = {"q": res, "f1": form1, "f2": form2, "f3": form3}
            return render(request, "searchc.html", cont1)
        elif sectorname == '' and username == '' and problem == 'HardWare':
            res = hw_malfunction.objects.all()
            cont1 = {"q": res, "f1": form1, "f2": form2, "f3": form3}
            return render(request, "searchc.html", cont1)

        elif sectorname == '' and username == '' and problem == 'Network':
            res = nw_malfunction.objects.all()
            cont1 = {"q": res, "f1": form1, "f2": form2, "f3": form3}
            return render(request, "searchc.html", cont1)
        elif sectorname == '' and username == '' and problem == 'Print':
            res = print_malfunction.objects.all()
            cont1 = {"q": res, "f1": form1, "f2": form2, "f3": form3}
            return render(request, "searchc.html", cont1)
        elif sectorname == '' and problem == '' and username:
            hw_qs = hw_malfunction.objects.filter(user_sector__icontains=sectorname, user_fullname__icontains=username)
            nw_qs = nw_malfunction.objects.filter(user_sector__icontains=sectorname, user_fullname__icontains=username)
            p_qs = print_malfunction.objects.filter(user_sector__icontains=sectorname,
                                                    user_fullname__icontains=username)
            res = list(chain(hw_qs, nw_qs, p_qs))
            cont1 = {"q": res, "f1": form1, "f2": form2, "f3": form3}
            return render(request, "searchc.html", cont1)

    context = {"f1": form1, "f2": form2, "f3": form3, }
    return render(request, "searchc.html", context)